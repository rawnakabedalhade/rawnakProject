## my account

An application that allows users to manage and customize their account settings.

**Installation**
Nothing to download

**Features**
Managing expenses and income. you can add the description and the amount. you get a calculated balance so you can keep track on your expenses and income.

**coding**
HTML5
CSS
Bootstrap
JavaScript.

**Copyright**
Rawnak Abed Alhade

## Countries of the World API

An API providing information about countries around the world.

**Description**
The Countries of the World API offers information about various countries, including details such as population, capital, currency, and more. It provides a RESTful interface for developers to access country-related data programmatically.

**Technologies Used**
HTML5
JavaScript
BootStrap
Css

**Installation**
Nothing to install

**Copyright**
Rawnak Abed Alhade

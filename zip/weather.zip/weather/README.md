## Weather App

A simple Weather App that provides current weather information using a weather API.

**Description**
The Weather App fetches current weather data from a weather API and displays it in a user-friendly interface. Users can enter the location (city, country) to get real-time weather information.

**Features**
Display current temperature, weather conditions, and other relevant details
Dynamic background based on weather conditions
Search for weather information by location

**API Used**
This Weather App uses the Weather API Provider.

**Installation**
Nothing to install

**Copyright**
Rawnak Abed Alhade

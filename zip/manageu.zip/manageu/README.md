# Manage U

A project management tool to streamline tasks.

**Overview**
The Project Management Tool is designed to assist you in organizing and managing your tasks efficiently.

**Technologies Used**
HTML5
JavaScript
Css
BootStrap

**Installation**
Nothing to install

**Copyright**
Rawnak Abed Alhade

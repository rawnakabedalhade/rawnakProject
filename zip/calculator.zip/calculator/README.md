## Calculator

A classic Snake game implemented in [JavaScript, HTML5, CSS].

**Description**
The Calculator is a simple application that performs basic arithmetic operations, such as addition, subtraction, multiplication, and division. It provides a user-friendly interface for performing calculations.

**Installation**
Nothing to install

**Copyright**
Rawnak Abed Alhade

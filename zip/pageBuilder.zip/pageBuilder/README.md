## Page Builder

A flexible and user-friendly Page Builder application for creating and customizing web pages without coding.

**Description**
The Page Builder is an intuitive tool that empowers users to design and build web pages effortlessly.allowing users to add, delete elements on the page.

**Technologies Used**
HTML5
JavaScript
Css

**Installation**
Nothing to install

**Copyright**
Rawnak Abed Alhade
